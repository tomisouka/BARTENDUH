import { T } from "../theme";
import { S } from "../styles";

export default function DataTable({ rows, cols }) {
  return (
    <div style={{ overflowX: "auto", borderRadius: 10, border: `1px solid ${T.border}` }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>{cols.map(c => <th key={c} style={S.th}>{c}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent" }}>
              {Object.values(row).map((v, j) => <td key={j} style={S.td}>{v}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
