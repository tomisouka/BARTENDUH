export const MOCKTAILS = [
  {
    category: "Classic Mocktails", color: "#6B8E3E",
    recipes: [
      { name: "Shirley Temple",     method: "BUILD",          ingredients: ["6 oz ginger ale", "0.5 oz grenadine"], steps: ["Fill glass with ice", "Add ginger ale", "Pour grenadine down side for layered effect — do not stir"], garnish: "2-3 Maraschino cherries", glass: "Highball", notes: "Roy Rogers variation: use cola instead of ginger ale." },
      { name: "Virgin Mojito",      method: "MUDDLE + BUILD", ingredients: ["10-12 fresh mint leaves", "1 oz fresh lime juice", "0.75 oz simple syrup", "4-5 oz club soda"], steps: ["Gently muddle mint + simple in glass", "Add lime juice and ice", "Top with club soda, stir gently"], garnish: "Mint sprig + lime wedge", glass: "Highball" },
      { name: "Virgin Piña Colada", method: "BLEND",          ingredients: ["2 oz pineapple juice", "1.5 oz cream of coconut (Coco López)", "1 oz heavy cream"], steps: ["Blend all with 1-1.5 cups ice until smooth"], garnish: "Pineapple wedge + cherry", glass: "Hurricane" },
    ]
  },
  {
    category: "Fruity & Refreshing", color: "#4A90A4",
    recipes: [
      { name: "Strawberry Basil Smash",  method: "MUDDLE + SHAKE", ingredients: ["4-5 fresh strawberries", "4-5 basil leaves", "1 oz lemon juice", "0.75 oz simple syrup", "2-3 oz club soda"], steps: ["Muddle strawberries and basil in shaker", "Add lemon, simple, ice — shake hard 10s", "Strain over fresh ice, top with club soda"], garnish: "Strawberry + basil leaf", glass: "Rocks or highball" },
      { name: "Watermelon Mint Cooler",  method: "MUDDLE + BUILD", ingredients: ["4 oz fresh watermelon juice", "0.5 oz lime juice", "0.5 oz agave syrup", "6-8 mint leaves", "2 oz sparkling water"], steps: ["Muddle mint in glass", "Add watermelon juice, lime, agave, ice", "Top with sparkling water, stir gently"], garnish: "Watermelon wedge + mint sprig", glass: "Highball" },
      { name: "Tropical Sunrise",        method: "BUILD",          ingredients: ["3 oz orange juice", "2 oz pineapple juice", "0.5 oz grenadine", "Splash coconut water"], steps: ["Add OJ, pineapple, coconut water over ice", "Slowly pour grenadine down side — do NOT stir for sunrise effect"], garnish: "Orange slice + cherry", glass: "Highball" },
    ]
  },
  {
    category: "Sophisticated", color: "#8B7BA8",
    recipes: [
      { name: "Citrus Rosemary Spritz",    method: "BUILD",          ingredients: ["2 oz fresh grapefruit juice", "0.5 oz lemon juice", "0.5 oz rosemary simple syrup", "3 oz club soda"], steps: ["Fill wine glass with ice", "Add juices and rosemary syrup", "Top with club soda, stir gently"], garnish: "Rosemary sprig + grapefruit slice", glass: "Wine glass" },
      { name: "Cucumber Elderflower Fizz", method: "MUDDLE + BUILD", ingredients: ["3-4 cucumber slices", "1 oz elderflower syrup", "0.5 oz lime juice", "4 oz sparkling water"], steps: ["Muddle cucumber in glass", "Add elderflower syrup, lime, ice", "Top with sparkling water"], garnish: "Cucumber ribbon + edible flowers", glass: "Highball or wine glass" },
      { name: "Virgin Espresso Martini",   method: "SHAKE HARD",     ingredients: ["2 oz fresh espresso (cooled)", "1 oz coffee syrup", "0.5 oz heavy cream (optional)"], steps: ["Cool espresso to room temp", "Shake hard 15-20s to build foam", "Strain into chilled glass"], garnish: "3 coffee beans on foam", glass: "Martini" },
    ]
  },
  {
    category: "Party Punches", color: "#C9A84C",
    recipes: [
      { name: "Berry Lemonade Punch",   method: "BUILD (serves 8-10)", ingredients: ["4 cups lemonade", "2 cups mixed berry juice", "1 cup sliced strawberries", "1 cup blueberries", "1 cup raspberries", "2 cups ginger ale or club soda"], steps: ["Combine lemonade and berry juice in punch bowl", "Add sliced fruit", "Refrigerate 1-2 hours", "Add ginger ale and ice just before serving"], garnish: "Mint sprigs + berry skewers", glass: "Punch bowl" },
      { name: "Tropical Fruit Punch",   method: "BUILD (serves 6-8)",  ingredients: ["2 cups pineapple juice", "1 cup orange juice", "1 cup mango juice", "1 cup coconut water", "1 cup club soda", "Fresh pineapple chunks"], steps: ["Combine all juices and coconut water", "Refrigerate until chilled", "Add club soda just before serving", "Serve over ice"], garnish: "Pineapple chunks + cherries", glass: "Punch bowl or pitcher" },
    ]
  },
];
