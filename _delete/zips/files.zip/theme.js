export const T = {
  bg:      "#0D0B08",
  surface: "rgba(255,255,255,0.03)",
  border:  "rgba(255,255,255,0.07)",
  gold:    "#C9A84C",
  amber:   "#D4712B",
  cream:   "#F0E6D3",
  muted:   "rgba(240,230,211,0.45)",
  dim:     "rgba(240,230,211,0.2)",
};

export const SECTION_COLORS = {
  techniques: "#4A90A4",
  classics:   "#C9A84C",
  specialty:  "#D4712B",
  spirits:    "#A0522D",
  beer:       "#D4820A",
  wine:       "#8B1A35",
  mocktails:  "#6B8E3E",
  baker:      "#8B7BA8",
};
