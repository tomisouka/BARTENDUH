import Section from "../components/Section";
import RecipeCard from "../components/RecipeCard";
import { MOCKTAILS } from "../data/mocktails";

export default function MocktailsPage() {
  return (
    <div>
      {MOCKTAILS.map((cat, i) => (
        <Section key={i} title={cat.category} color={cat.color}>
          {cat.recipes.map((r, ri) => (
            <RecipeCard key={ri} recipe={r} accent={cat.color} />
          ))}
        </Section>
      ))}
    </div>
  );
}
