import { T } from './theme';

export const S = {
  backBtn:  { background: "transparent", border: `1px solid ${T.border}`, color: T.muted, padding: "7px 14px", borderRadius: 8, cursor: "pointer", fontSize: 12, fontFamily: "inherit", marginBottom: 36 },
  card:     { border: `1px solid ${T.border}`, borderRadius: 12, marginBottom: 8, overflow: "hidden", transition: "border-color 0.2s" },
  cardHead: { display: "flex", alignItems: "center", padding: "13px 16px", cursor: "pointer", gap: 8, flexWrap: "wrap" },
  cardBody: { padding: "0 16px 16px", borderTop: `1px solid ${T.border}` },
  rName:    { fontSize: 14, fontWeight: "bold", color: T.cream },
  rSpirit:  { fontSize: 11, color: T.muted },
  rMethod:  { fontSize: 10, letterSpacing: "0.15em", textTransform: "uppercase", marginLeft: "auto" },
  ingrList: { display: "flex", flexDirection: "column", marginTop: 12 },
  ingr:     { fontSize: 13, color: T.cream, lineHeight: 1.9 },
  step:     { fontSize: 13, color: T.cream, lineHeight: 1.8, marginBottom: 2 },
  tags:     { display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12 },
  tag:      { fontSize: 11, padding: "3px 9px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 20, color: T.muted },
  variation:{ fontSize: 12, color: T.muted, lineHeight: 1.8 },
  noteBox:  { marginTop: 10, padding: "9px 12px", background: "rgba(255,255,255,0.03)", borderRadius: 8, fontSize: 12, color: T.muted, lineHeight: 1.7, fontStyle: "italic" },
  th:       { padding: "9px 14px", textAlign: "left", fontSize: 10, letterSpacing: "0.12em", textTransform: "uppercase", color: T.muted, borderBottom: `1px solid ${T.border}`, background: "rgba(255,255,255,0.03)" },
  td:       { padding: "9px 14px", fontSize: 13, color: T.cream, borderBottom: `1px solid rgba(255,255,255,0.04)` },
  subTitle: { fontSize: 17, fontWeight: "bold", marginBottom: 14, letterSpacing: "0.02em" },
};
