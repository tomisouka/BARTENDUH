import { useState } from "react";
import { T } from "../theme";
import { S } from "../styles";

export default function RecipeCard({ recipe, accent }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ ...S.card, borderColor: open ? accent + "55" : T.border }}>
      <div onClick={() => setOpen(!open)} style={S.cardHead}>
        <div style={{ flex: 1 }}>
          <span style={S.rName}>{recipe.name}</span>
          {recipe.spirit && <span style={{ ...S.rSpirit, marginLeft: 6 }}> · {recipe.spirit}</span>}
        </div>
        {recipe.method && <span style={{ ...S.rMethod, color: accent }}>{recipe.method}</span>}
        <span style={{ color: T.dim, marginLeft: 8, fontSize: 11 }}>{open ? "▲" : "▼"}</span>
      </div>
      {open && (
        <div style={S.cardBody}>
          <div style={S.ingrList}>
            {recipe.ingredients.map((ing, i) => (
              <span key={i} style={S.ingr}>· {ing}</span>
            ))}
          </div>
          {recipe.steps && (
            <div style={{ marginTop: 12 }}>
              {recipe.steps.map((s, i) => (
                <div key={i} style={S.step}>
                  <span style={{ color: accent, fontWeight: "bold" }}>{i + 1}.</span> {s}
                </div>
              ))}
            </div>
          )}
          <div style={S.tags}>
            {recipe.glass   && <span style={S.tag}>🥃 {recipe.glass}</span>}
            {recipe.garnish && <span style={S.tag}>✨ {recipe.garnish}</span>}
          </div>
          {recipe.variations && (
            <div style={{ marginTop: 10 }}>
              {recipe.variations.map((v, i) => (
                <div key={i} style={S.variation}>↳ {v}</div>
              ))}
            </div>
          )}
          {(recipe.notes || recipe.tip) && (
            <div style={S.noteBox}>📝 {recipe.notes || recipe.tip}</div>
          )}
        </div>
      )}
    </div>
  );
}
