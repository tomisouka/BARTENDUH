import Section from "../components/Section";
import ClickCard from "../components/ClickCard";
import DataTable from "../components/DataTable";
import { FUNDAMENTALS, CORE_SPIRITS, MODIFIERS, GLASSWARE, BAR_TERMS, RATIOS } from "../data/techniques";

export default function TechniquesPage() {
  return (
    <div>
      <Section title="The Five Fundamentals" color="#4A90A4">
        {FUNDAMENTALS.map((item, i) => <ClickCard key={i} item={item} accent="#4A90A4" />)}
      </Section>
      <Section title="Core Spirits" color="#C9A84C">
        {CORE_SPIRITS.map((item, i) => <ClickCard key={i} item={item} accent="#C9A84C" />)}
      </Section>
      <Section title="Key Modifiers" color="#D4712B">
        {MODIFIERS.map((item, i) => <ClickCard key={i} item={item} accent="#D4712B" />)}
      </Section>
      <Section title="Golden Ratios" color="#A0522D">
        {RATIOS.map((item, i) => <ClickCard key={i} item={item} accent="#A0522D" />)}
      </Section>
      <Section title="Glassware" color="#8B7BA8">
        <DataTable rows={GLASSWARE} cols={["Glass", "Size", "Best For"]} />
      </Section>
      <Section title="Bar Terms Glossary" color="#6B8E3E">
        <DataTable rows={BAR_TERMS} cols={["Term", "Meaning"]} />
      </Section>
    </div>
  );
}
