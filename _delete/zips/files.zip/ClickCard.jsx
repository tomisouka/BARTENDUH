import { useState } from "react";
import { T } from "../theme";
import { S } from "../styles";

export default function ClickCard({ item, accent }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      onClick={() => setOpen(!open)}
      style={{ ...S.card, borderColor: open ? accent + "55" : T.border, cursor: "pointer" }}
    >
      <div style={S.cardHead}>
        <span style={{ ...S.rName, color: open ? accent : T.cream, transition: "color 0.2s", flex: 1 }}>
          {item.name || item.term}
        </span>
        <span style={S.rSpirit}>{item.detail || item.def}</span>
      </div>
      {open && item.notes    && <div style={{ ...S.noteBox, margin: "0 16px 12px" }}>{item.notes}</div>}
      {open && item.examples && <div style={{ ...S.variation, color: accent, padding: "0 16px 12px" }}>e.g. {item.examples}</div>}
    </div>
  );
}
