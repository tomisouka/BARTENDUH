export default function Section({ title, color, children }) {
  return (
    <div style={{ marginBottom: 44 }}>
      <h3 style={{ fontSize: 17, fontWeight: "bold", color, marginBottom: 14, letterSpacing: "0.02em" }}>
        {title}
      </h3>
      {children}
    </div>
  );
}
