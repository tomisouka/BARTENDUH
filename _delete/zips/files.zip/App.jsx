import { useState } from "react";
import { T } from "./theme";
import { S } from "./styles";

// Pages
import TechniquesPage  from "./pages/TechniquesPage";
import ClassicsPage    from "./pages/ClassicsPage";
import SpecialtyPage   from "./pages/SpecialtyPage";
import MocktailsPage   from "./pages/MocktailsPage";
import PlaceholderPage from "./pages/PlaceholderPage";

// ── Section registry ──────────────────────────────────────────────────────────
// Add new sections here only. Everything else lives in its own file.
const SECTIONS = [
  { id: "techniques", title: "Techniques & Fundamentals", emoji: "🧊", color: "#4A90A4", desc: "The five methods, terms, ratios, glassware, golden rules",   page: TechniquesPage },
  { id: "classics",   title: "Classic Cocktails",         emoji: "🍸", color: "#C9A84C", desc: "Spirit-forward, sours, highballs, aperitifs, dessert drinks", page: ClassicsPage },
  { id: "specialty",  title: "Specialty Recipes",         emoji: "🍹", color: "#D4712B", desc: "Baker bar menu — Old Fashioneds, Margaritas, Vodka & more",   page: SpecialtyPage },
  { id: "mocktails",  title: "Mocktails",                 emoji: "🥤", color: "#6B8E3E", desc: "Classics, fruity, sophisticated, and party punches",          page: MocktailsPage },
  { id: "spirits",    title: "Spirits Encyclopedia",      emoji: "🥃", color: "#A0522D", desc: "Vodka, gin, rum, tequila, whiskey, brandy — full deep dives", page: null },
  { id: "beer",       title: "Beer Guide",                emoji: "🍺", color: "#D4820A", desc: "Top brands, styles, how to choose, quick reference",          page: null },
  { id: "wine",       title: "Wine Guide",                emoji: "🍷", color: "#8B1A35", desc: "Reds, whites, rosé, champagne, regions, serving",             page: null },
  { id: "baker",      title: "Baker Bar Menu",            emoji: "🏛️", color: "#8B7BA8", desc: "Full house menu — beers, wines, cocktails by category",       page: null },
];

// ── Dashboard card ────────────────────────────────────────────────────────────
function DashboardCard({ section, onClick }) {
  const [hovered, setHovered] = useState(false);
  const ready = !!section.page;
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: T.surface,
        border: `1px solid ${hovered ? section.color : T.border}`,
        borderRadius: 16,
        padding: 24,
        cursor: "pointer",
        transition: "all 0.25s ease",
        transform: hovered ? "translateY(-4px)" : "translateY(0)",
        boxShadow: hovered ? `0 12px 40px rgba(0,0,0,0.5), 0 0 0 1px ${section.color}40` : "0 4px 20px rgba(0,0,0,0.3)",
        opacity: ready ? 1 : 0.6,
      }}
    >
      <div style={{ marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <span style={{ fontSize: 28 }}>{section.emoji}</span>
        {!ready && <span style={{ fontSize: 9, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase", border: `1px solid ${T.border}`, padding: "2px 7px", borderRadius: 10 }}>Soon</span>}
      </div>
      <h2 style={{ fontSize: 14, fontWeight: "bold", color: hovered ? section.color : T.cream, margin: "0 0 7px", transition: "color 0.25s" }}>
        {section.title}
      </h2>
      <p style={{ fontSize: 11, color: T.muted, lineHeight: 1.6, margin: "0 0 16px" }}>{section.desc}</p>
      <div style={{ height: 2, borderRadius: 2, width: 32, background: hovered ? section.color : "rgba(255,255,255,0.1)", transition: "background 0.25s" }} />
    </div>
  );
}

// ── Section shell (wraps any page) ───────────────────────────────────────────
function SectionShell({ section, onBack }) {
  const PageComponent = section.page;
  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: "36px 32px 80px" }}>
      <button onClick={onBack} style={S.backBtn}>← Dashboard</button>
      <div style={{ textAlign: "center", marginBottom: 48 }}>
        <span style={{ fontSize: 50, display: "block", marginBottom: 14 }}>{section.emoji}</span>
        <h1 style={{ fontSize: 28, fontWeight: "bold", color: section.color, margin: "0 0 10px" }}>{section.title}</h1>
        <p style={{ color: T.muted, fontSize: 13 }}>{section.desc}</p>
      </div>
      {PageComponent ? <PageComponent /> : <PlaceholderPage section={section} />}
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [active, setActive] = useState(null);
  const [search, setSearch] = useState("");

  const filtered = SECTIONS.filter(s =>
    !search ||
    s.title.toLowerCase().includes(search.toLowerCase()) ||
    s.desc.toLowerCase().includes(search.toLowerCase())
  );

  if (active) {
    return (
      <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Georgia', serif", color: T.cream }}>
        <SectionShell section={active} onBack={() => setActive(null)} />
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Georgia', serif", color: T.cream, position: "relative", overflowX: "hidden" }}>
      {/* Ambient orbs */}
      <div style={{ position: "fixed", top: "-200px", right: "-100px", width: "600px", height: "600px", borderRadius: "50%", background: "radial-gradient(circle, rgba(201,168,76,0.08) 0%, transparent 70%)", pointerEvents: "none" }} />
      <div style={{ position: "fixed", bottom: "-200px", left: "-100px", width: "500px", height: "500px", borderRadius: "50%", background: "radial-gradient(circle, rgba(160,82,45,0.07) 0%, transparent 70%)", pointerEvents: "none" }} />

      {/* Header */}
      <header style={{ borderBottom: `1px solid ${T.border}`, backdropFilter: "blur(10px)", background: "rgba(13,11,8,0.85)", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "14px 32px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 24 }}>🍹</span>
            <div>
              <div style={{ fontSize: 14, fontWeight: "bold", color: T.gold }}>Behind the Bar</div>
              <div style={{ fontSize: 9, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase" }}>Bartending Notes</div>
            </div>
          </div>
          <div style={{ fontSize: 11, color: T.muted }}>
            {SECTIONS.filter(s => s.page).length}/{SECTIONS.length} sections live
          </div>
        </div>
      </header>

      {/* Hero */}
      <section style={{ maxWidth: "1100px", margin: "0 auto", padding: "56px 32px 20px", textAlign: "center" }}>
        <h1 style={{ fontSize: "clamp(26px,5vw,44px)", fontWeight: "bold", margin: "0 0 12px", background: `linear-gradient(135deg, ${T.gold}, ${T.cream}, ${T.amber})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
          Your Bar, Your Knowledge
        </h1>
        <p style={{ fontSize: 13, color: T.muted, maxWidth: 440, margin: "0 auto", lineHeight: 1.7 }}>
          Everything you're learning behind the stick — organized, searchable, yours.
        </p>
      </section>

      {/* Search */}
      <div style={{ maxWidth: 480, margin: "20px auto", padding: "0 32px", position: "relative", display: "flex", alignItems: "center" }}>
        <span style={{ position: "absolute", left: 52, fontSize: 13, opacity: 0.4 }}>🔍</span>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search sections..."
          style={{ width: "100%", padding: "11px 16px 11px 38px", background: "rgba(255,255,255,0.05)", border: `1px solid ${T.border}`, borderRadius: 12, color: T.cream, fontSize: 13, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
        />
      </div>

      {/* Grid */}
      <main style={{ maxWidth: "1100px", margin: "0 auto", padding: "12px 32px 60px", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 16 }}>
        {filtered.map(s => (
          <DashboardCard key={s.id} section={s} onClick={() => setActive(s)} />
        ))}
      </main>

      <footer style={{ textAlign: "center", padding: "16px", fontSize: 9, color: T.dim, letterSpacing: "0.1em", textTransform: "uppercase", borderTop: `1px solid ${T.border}` }}>
        Behind the Bar · Phase 1
      </footer>
    </div>
  );
}
