import { useState } from "react";
import { T } from "./theme";

import TechniquesPage  from "./pages/TechniquesPage";
import ClassicsPage    from "./pages/ClassicsPage";
import SpecialtyPage   from "./pages/SpecialtyPage";
import MocktailsPage   from "./pages/MocktailsPage";
import SpiritsPage     from "./pages/SpiritsPage";
import BeerPage        from "./pages/BeerPage";
import WinePage        from "./pages/WinePage";
import BakerPage       from "./pages/BakerPage";
import PlaceholderPage from "./pages/PlaceholderPage";

const SECTIONS = [
  { id:"techniques", title:"Techniques & Fundamentals", emoji:"🧊", color:"#4A90A4", desc:"The five methods, terms, ratios, glassware, golden rules",    page:TechniquesPage },
  { id:"classics",   title:"Classic Cocktails",          emoji:"🍸", color:"#C9A84C", desc:"Spirit-forward, sours, highballs, aperitifs, dessert drinks",  page:ClassicsPage },
  { id:"specialty",  title:"Specialty Recipes",          emoji:"🍹", color:"#D4712B", desc:"Baker bar menu — Old Fashioneds, Margaritas, Vodka & more",    page:SpecialtyPage },
  { id:"mocktails",  title:"Mocktails",                  emoji:"🥤", color:"#6B8E3E", desc:"Classics, fruity, sophisticated, and party punches",           page:MocktailsPage },
  { id:"spirits",    title:"Spirits Encyclopedia",       emoji:"🥃", color:"#A0522D", desc:"Vodka, gin, rum, tequila, whiskey, brandy — full deep dives",  page:SpiritsPage },
  { id:"beer",       title:"Beer Guide",                 emoji:"🍺", color:"#D4820A", desc:"Top brands, styles, how to choose, quick reference",           page:BeerPage },
  { id:"wine",       title:"Wine Guide",                 emoji:"🍷", color:"#8B1A35", desc:"Reds, whites, rosé, champagne, regions, serving",              page:WinePage },
  { id:"baker",      title:"Baker Bar Menu",             emoji:"🏛️", color:"#8B7BA8", desc:"Full house menu — beers, wines, cocktails by category",        page:BakerPage },
];

function DashboardCard({ section, onClick, index }) {
  const [hov, setHov] = useState(false);
  return (
    <div
      className="card-hover fade-up"
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        animationDelay: `${index * 0.06}s`,
        background: hov
          ? `linear-gradient(135deg, ${section.color}18, ${T.card})`
          : T.card,
        border: `1px solid ${hov ? section.color + "60" : T.border}`,
        borderRadius: 16,
        padding: "28px 24px",
        cursor: "pointer",
        boxShadow: hov
          ? `0 20px 60px rgba(0,0,0,0.6), 0 0 0 1px ${section.color}30, inset 0 1px 0 rgba(255,255,255,0.05)`
          : "0 4px 24px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.03)",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Glow orb top-right */}
      <div style={{
        position:"absolute", top:-40, right:-40,
        width:120, height:120, borderRadius:"50%",
        background: `radial-gradient(circle, ${section.color}25 0%, transparent 70%)`,
        opacity: hov ? 1 : 0,
        transition: "opacity 0.3s ease",
        pointerEvents:"none",
      }}/>

      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
        <span style={{ fontSize:32, filter: hov ? "drop-shadow(0 0 8px currentColor)" : "none", transition:"filter 0.3s" }}>
          {section.emoji}
        </span>
        <span style={{
          fontSize:9, letterSpacing:"0.15em", textTransform:"uppercase",
          color: section.color, border:`1px solid ${section.color}40`,
          padding:"3px 8px", borderRadius:20,
          fontFamily:"'DM Mono', monospace",
        }}>
          {section.id}
        </span>
      </div>

      <h2 style={{
        fontSize:15, fontWeight:600, color: hov ? section.color : T.cream,
        margin:"0 0 8px", transition:"color 0.25s",
        fontFamily:"'Playfair Display', serif",
        letterSpacing:"0.01em",
      }}>
        {section.title}
      </h2>
      <p style={{ fontSize:12, color:T.muted, lineHeight:1.65, margin:"0 0 20px" }}>
        {section.desc}
      </p>

      {/* Bottom accent bar */}
      <div style={{
        height:2, borderRadius:2,
        background: hov
          ? `linear-gradient(90deg, ${section.color}, transparent)`
          : "rgba(255,255,255,0.06)",
        transition:"background 0.3s ease",
      }}/>
    </div>
  );
}

function SectionShell({ section, onBack }) {
  const PageComponent = section.page;
  return (
    <div style={{ minHeight:"100vh", background:T.bg, fontFamily:"'DM Sans', sans-serif", color:T.cream }}>
      {/* Section header bar */}
      <div style={{
        background: `linear-gradient(180deg, ${section.color}20 0%, transparent 100%)`,
        borderBottom:`1px solid ${section.color}30`,
        padding:"20px 32px",
        position:"sticky", top:0, zIndex:100,
        backdropFilter:"blur(12px)",
        display:"flex", alignItems:"center", gap:16,
      }}>
        <button
          onClick={onBack}
          style={{
            background:"rgba(255,255,255,0.06)",
            border:`1px solid ${T.border}`,
            color:T.muted, padding:"7px 16px",
            borderRadius:8, cursor:"pointer",
            fontSize:12, fontFamily:"inherit",
            transition:"all 0.2s",
          }}
          onMouseEnter={e => { e.target.style.background="rgba(255,255,255,0.1)"; e.target.style.color=T.cream; }}
          onMouseLeave={e => { e.target.style.background="rgba(255,255,255,0.06)"; e.target.style.color=T.muted; }}
        >
          ← Back
        </button>
        <span style={{ fontSize:22 }}>{section.emoji}</span>
        <span style={{ fontSize:16, fontWeight:700, fontFamily:"'Playfair Display', serif", color:section.color }}>
          {section.title}
        </span>
      </div>

      <div style={{ maxWidth:900, margin:"0 auto", padding:"40px 32px 80px" }}>
        {PageComponent ? <PageComponent accentColor={section.color} /> : <PlaceholderPage section={section} />}
      </div>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState(null);
  const [search, setSearch]   = useState("");

  if (active) return <SectionShell section={active} onBack={() => setActive(null)} />;

  const filtered = SECTIONS.filter(s =>
    !search ||
    s.title.toLowerCase().includes(search.toLowerCase()) ||
    s.desc.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ minHeight:"100vh", background:T.bg, fontFamily:"'DM Sans', sans-serif", color:T.cream, position:"relative" }}>

      {/* Background texture gradient */}
      <div style={{
        position:"fixed", inset:0, pointerEvents:"none", zIndex:0,
        background:"radial-gradient(ellipse 80% 50% at 50% -20%, rgba(201,168,76,0.07) 0%, transparent 60%)",
      }}/>
      <div style={{
        position:"fixed", bottom:0, left:0, right:0, height:300, pointerEvents:"none", zIndex:0,
        background:"radial-gradient(ellipse 60% 40% at 30% 100%, rgba(160,82,45,0.06) 0%, transparent 70%)",
      }}/>

      {/* Header */}
      <header style={{
        borderBottom:`1px solid ${T.border}`,
        backdropFilter:"blur(16px)",
        background:"rgba(8,6,4,0.8)",
        position:"sticky", top:0, zIndex:100,
      }}>
        <div style={{ maxWidth:1100, margin:"0 auto", padding:"16px 32px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <div style={{
              width:36, height:36, borderRadius:10,
              background:`linear-gradient(135deg, ${T.gold}, ${T.amber})`,
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:18, boxShadow:`0 4px 16px rgba(201,168,76,0.3)`,
            }}>🍹</div>
            <div>
              <div style={{ fontSize:15, fontWeight:700, fontFamily:"'Playfair Display', serif", color:T.gold, letterSpacing:"0.03em" }}>
                Behind the Bar
              </div>
              <div style={{ fontSize:9, color:T.dim, letterSpacing:"0.15em", textTransform:"uppercase", fontFamily:"'DM Mono', monospace" }}>
                Bartending Notes
              </div>
            </div>
          </div>
          <div style={{
            fontSize:11, color:T.dim, fontFamily:"'DM Mono', monospace",
            letterSpacing:"0.08em",
          }}>
            {SECTIONS.length} sections · {SECTIONS.filter(s=>s.page).length} live
          </div>
        </div>
      </header>

      <div style={{ position:"relative", zIndex:1 }}>
        {/* Hero */}
        <section style={{ maxWidth:1100, margin:"0 auto", padding:"64px 32px 16px", textAlign:"center" }}
          className="fade-up">
          <div style={{
            display:"inline-block", fontSize:10, letterSpacing:"0.2em", textTransform:"uppercase",
            color:T.gold, border:`1px solid ${T.gold}40`, padding:"4px 16px", borderRadius:20,
            marginBottom:20, fontFamily:"'DM Mono', monospace",
          }}>
            Your Personal Bar Reference
          </div>
          <h1 style={{
            fontSize:"clamp(32px,6vw,56px)", fontWeight:900,
            fontFamily:"'Playfair Display', serif",
            margin:"0 0 16px",
            background:`linear-gradient(135deg, ${T.gold} 0%, ${T.cream} 40%, ${T.amber} 100%)`,
            WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundClip:"text",
            lineHeight:1.1, letterSpacing:"-0.01em",
          }}>
            Your Bar,<br/>Your Knowledge
          </h1>
          <p style={{ fontSize:14, color:T.muted, maxWidth:460, margin:"0 auto", lineHeight:1.75 }}>
            Everything you're learning behind the stick — organized, searchable, and always in reach.
          </p>
        </section>

        {/* Search */}
        <div style={{ maxWidth:500, margin:"28px auto", padding:"0 32px" }}>
          <div style={{ position:"relative" }}>
            <span style={{ position:"absolute", left:16, top:"50%", transform:"translateY(-50%)", fontSize:14, opacity:0.35 }}>🔍</span>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search sections..."
              style={{
                width:"100%", padding:"13px 16px 13px 44px",
                background:"rgba(255,255,255,0.04)",
                border:`1px solid ${T.border}`,
                borderRadius:12, color:T.cream, fontSize:13,
                outline:"none", transition:"border-color 0.2s",
                letterSpacing:"0.01em",
              }}
              onFocus={e => e.target.style.borderColor = T.gold + "60"}
              onBlur={e  => e.target.style.borderColor = T.border}
            />
          </div>
        </div>

        {/* Grid */}
        <main style={{
          maxWidth:1100, margin:"0 auto",
          padding:"8px 32px 80px",
          display:"grid",
          gridTemplateColumns:"repeat(auto-fill, minmax(260px, 1fr))",
          gap:16,
        }}>
          {filtered.map((s, i) => (
            <DashboardCard key={s.id} section={s} index={i} onClick={() => setActive(s)} />
          ))}
        </main>

        <footer style={{
          textAlign:"center", padding:"20px",
          fontSize:10, color:T.dim, letterSpacing:"0.15em", textTransform:"uppercase",
          fontFamily:"'DM Mono', monospace",
          borderTop:`1px solid ${T.border}`,
        }}>
          Behind the Bar · Study Edition
        </footer>
      </div>
    </div>
  );
}
