import { T } from "../theme";

export default function DataTable({ headers, rows, accent = T.gold }) {
  return (
    <div style={{
      borderRadius: 12, overflow: "hidden",
      border: `1px solid ${T.border}`,
      marginBottom: 16,
    }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ background: `${accent}15` }}>
            {headers.map((h, i) => (
              <th key={i} style={{
                padding: "10px 16px", textAlign: "left",
                fontSize: 9, letterSpacing: "0.15em", textTransform: "uppercase",
                color: accent, borderBottom: `1px solid ${accent}30`,
                fontFamily: "'DM Mono', monospace", fontWeight: 500,
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, ri) => (
            <tr key={ri} style={{
              background: ri % 2 === 0 ? "transparent" : "rgba(255,255,255,0.02)",
            }}>
              {row.map((cell, ci) => (
                <td key={ci} style={{
                  padding: "10px 16px", fontSize: 13,
                  color: ci === 0 ? T.cream : T.muted,
                  fontWeight: ci === 0 ? 500 : 400,
                  borderBottom: ri < rows.length - 1 ? `1px solid ${T.border}` : "none",
                  lineHeight: 1.5,
                }}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
