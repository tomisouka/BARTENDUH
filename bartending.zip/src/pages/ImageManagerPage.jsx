import { useState, useMemo, useRef } from "react";
import { T } from "../theme";
import { LIQUOR_IMAGES } from "../data/images";
import { LIQUOR } from "../data/baker";

// Derive category lists from LIQUOR data — stays in sync automatically
const getName = x => typeof x === "string" ? x : x.name;
const getNames = arr => arr.map(getName);

const WHISKEY_KEYS = ["bourbon", "tennessee", "rye", "irish", "canadian", "flavored"];

const CATEGORIES = {
  "All":      null,
  "Vodka":    getNames(LIQUOR.vodka),
  "Gin":      getNames(LIQUOR.gin),
  "Rum":      getNames(LIQUOR.rum),
  "Tequila":  getNames(LIQUOR.tequila),
  "Whiskey":  WHISKEY_KEYS.flatMap(k => getNames(LIQUOR[k] || [])),
  "Scotch":   getNames(LIQUOR.scotch),
  "Cognac":   getNames(LIQUOR.cognac),
  "Cordials": getNames(LIQUOR.cordials.filter(x => typeof x === "object")).concat(
               LIQUOR.cordials.filter(x => typeof x === "string")
              ),
};

function BrandRow({ name, url, onSave, onRemove }) {
  const [imgErr, setImgErr]   = useState(false);
  const [editing, setEditing] = useState(!url); // auto-open edit if no URL
  const [draft, setDraft]     = useState(url || "");
  const hasSrc = url && url.trim() && !imgErr;

  const handleSave = () => {
    onSave(name, draft.trim());
    setEditing(false);
    setImgErr(false);
  };
  const handleCancel = () => {
    setDraft(url || "");
    setEditing(false);
  };

  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 14px",
      background: editing ? "rgba(201,168,76,0.04)" : "rgba(255,255,255,0.025)",
      border: `1px solid ${editing ? T.gold + "40" : T.border}`,
      borderRadius: 10,
      flexWrap: editing ? "wrap" : "nowrap",
      transition: "all 0.15s",
    }}>
      {/* Thumb */}
      <div style={{ width: 40, height: 50, flexShrink: 0, borderRadius: 6, background: "rgba(255,255,255,0.04)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", border: `1px solid ${T.border}` }}>
        {hasSrc
          ? <img src={url} alt={name} style={{ maxWidth: 36, maxHeight: 46, objectFit: "contain" }} onError={() => setImgErr(true)} />
          : <span style={{ fontSize: 18, opacity: 0.3 }}>🍶</span>
        }
      </div>

      {/* Name + url / input */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: T.cream, marginBottom: 2 }}>{name}</div>
        {editing ? (
          <input
            autoFocus
            value={draft}
            onChange={e => setDraft(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") handleCancel(); }}
            placeholder="Paste image URL…"
            style={{ width: "100%", padding: "6px 10px", background: "rgba(255,255,255,0.06)", border: `1px solid ${T.gold}60`, borderRadius: 6, color: T.cream, fontSize: 12, fontFamily: "'DM Mono', monospace", outline: "none", boxSizing: "border-box", marginTop: 2 }}
          />
        ) : (
          hasSrc
            ? <div style={{ fontSize: 10, color: T.dim, fontFamily: "'DM Mono', monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{url}</div>
            : <div style={{ fontSize: 10, color: "#e05a5a", fontFamily: "'DM Mono', monospace" }}>No image</div>
        )}
      </div>

      {/* Status badge */}
      {!editing && (
        <span style={{ fontSize: 10, padding: "3px 8px", borderRadius: 16, flexShrink: 0, fontFamily: "'DM Mono', monospace", letterSpacing: "0.08em", background: hasSrc ? "#6B8E3E20" : "#e05a5a18", color: hasSrc ? "#6B8E3E" : "#e05a5a", border: `1px solid ${hasSrc ? "#6B8E3E40" : "#e05a5a30"}` }}>
          {hasSrc ? "✓ ok" : "missing"}
        </span>
      )}

      {/* Action buttons */}
      {editing ? (
        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          <button onClick={handleSave} style={{ padding: "6px 14px", background: `${T.gold}20`, border: `1px solid ${T.gold}60`, borderRadius: 6, color: T.gold, fontSize: 12, fontFamily: "'DM Mono', monospace", cursor: "pointer" }}>Save</button>
          <button onClick={handleCancel} style={{ padding: "6px 10px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.dim, fontSize: 12, fontFamily: "'DM Mono', monospace", cursor: "pointer" }}>✕</button>
        </div>
      ) : (
        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          <button
            onClick={() => { setDraft(url || ""); setEditing(true); }}
            style={{ padding: "5px 10px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.muted, fontSize: 11, fontFamily: "'DM Mono', monospace", cursor: "pointer", transition: "all 0.15s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = T.gold + "60"; e.currentTarget.style.color = T.gold; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.color = T.muted; }}
          >✎ Edit</button>
          <button
            onClick={() => { if (window.confirm(`Remove "${name}" from the image list?`)) onRemove(name); }}
            style={{ padding: "5px 8px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.dim, fontSize: 11, fontFamily: "'DM Mono', monospace", cursor: "pointer", transition: "all 0.15s" }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "#e05a5a60"; e.currentTarget.style.color = "#e05a5a"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.color = T.dim; }}
          >✕</button>
        </div>
      )}
    </div>
  );
}

// ── Add brand row ──────────────────────────────────────────────────────────
function AddBrandRow({ onAdd }) {
  const [open, setOpen]     = useState(false);
  const [name, setName]     = useState("");
  const [url, setUrl]       = useState("");

  const handleAdd = () => {
    if (!name.trim()) return;
    onAdd(name.trim(), url.trim());
    setName(""); setUrl(""); setOpen(false);
  };

  if (!open) return (
    <button onClick={() => setOpen(true)}
      style={{ width: "100%", padding: "10px", background: "rgba(255,255,255,0.025)", border: `1px dashed ${T.border}`, borderRadius: 10, color: T.dim, fontSize: 13, fontFamily: "'DM Mono', monospace", cursor: "pointer", letterSpacing: "0.05em", transition: "all 0.15s" }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = T.gold + "60"; e.currentTarget.style.color = T.gold; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = T.border; e.currentTarget.style.color = T.dim; }}
    >+ Add Brand</button>
  );

  return (
    <div style={{ padding: "14px", background: "rgba(201,168,76,0.04)", border: `1px solid ${T.gold}40`, borderRadius: 10, display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: T.gold, letterSpacing: "0.15em", textTransform: "uppercase" }}>Add New Brand</div>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Brand name (e.g. Ketel One)" autoFocus
        style={{ padding: "7px 10px", background: "rgba(255,255,255,0.06)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.cream, fontSize: 13, fontFamily: "inherit", outline: "none" }} />
      <input value={url} onChange={e => setUrl(e.target.value)} placeholder="Image URL (optional)" onKeyDown={e => e.key === "Enter" && handleAdd()}
        style={{ padding: "7px 10px", background: "rgba(255,255,255,0.06)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.cream, fontSize: 12, fontFamily: "'DM Mono', monospace", outline: "none" }} />
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={handleAdd} style={{ padding: "7px 18px", background: `${T.gold}20`, border: `1px solid ${T.gold}60`, borderRadius: 6, color: T.gold, fontSize: 12, fontFamily: "'DM Mono', monospace", cursor: "pointer" }}>Add</button>
        <button onClick={() => { setOpen(false); setName(""); setUrl(""); }} style={{ padding: "7px 12px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 6, color: T.dim, fontSize: 12, fontFamily: "'DM Mono', monospace", cursor: "pointer" }}>Cancel</button>
      </div>
    </div>
  );
}

// ── Export modal ───────────────────────────────────────────────────────────
function ExportModal({ urls, onClose }) {
  const textRef = useRef(null);
  const [copied, setCopied] = useState(false);

  const code = `export const LIQUOR_IMAGES = {\n${Object.entries(urls).map(([k, v]) => `  ${JSON.stringify(k)}: ${JSON.stringify(v)},`).join("\n")}\n};`;

  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ background: "#100e18", border: `1px solid ${T.border}`, borderRadius: 16, width: "100%", maxWidth: 700, maxHeight: "85vh", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "18px 20px 14px", borderBottom: `1px solid ${T.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, fontWeight: 700, color: T.gold }}>Export to images.js</div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: T.dim, marginTop: 3 }}>Copy this block and replace the <code style={{ color: T.gold }}>LIQUOR_IMAGES</code> export in <code style={{ color: T.gold }}>src/data/images.js</code></div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", color: T.dim, fontSize: 18, cursor: "pointer", padding: 4 }}>✕</button>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "14px 20px" }}>
          <pre ref={textRef} style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#c8b898", lineHeight: 1.7, margin: 0, whiteSpace: "pre-wrap", wordBreak: "break-all", background: "#0a0810", border: `1px solid ${T.border}`, borderRadius: 8, padding: "14px" }}>{code}</pre>
        </div>
        <div style={{ padding: "14px 20px", borderTop: `1px solid ${T.border}`, display: "flex", gap: 10 }}>
          <button onClick={handleCopy}
            style={{ flex: 1, padding: "10px", background: copied ? "#6B8E3E20" : `${T.gold}20`, border: `1px solid ${copied ? "#6B8E3E60" : T.gold + "60"}`, borderRadius: 8, color: copied ? "#6B8E3E" : T.gold, fontFamily: "'DM Mono', monospace", fontSize: 13, cursor: "pointer", letterSpacing: "0.05em", transition: "all 0.2s" }}>
            {copied ? "✓ Copied!" : "Copy to Clipboard"}
          </button>
          <button onClick={onClose} style={{ padding: "10px 20px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 8, color: T.dim, fontFamily: "'DM Mono', monospace", fontSize: 13, cursor: "pointer" }}>Close</button>
        </div>
      </div>
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────────────────
export default function ImageManagerPage() {
  const [urls,       setUrls]       = useState({ ...LIQUOR_IMAGES });
  const [cat,        setCat]        = useState("All");
  const [filter,     setFilter]     = useState("all");
  const [search,     setSearch]     = useState("");
  const [showExport, setShowExport] = useState(false);

  const handleSave   = (name, url)  => setUrls(prev => ({ ...prev, [name]: url }));
  const handleRemove = (name)       => setUrls(prev => { const n = { ...prev }; delete n[name]; return n; });
  const handleAdd    = (name, url)  => setUrls(prev => ({ ...prev, [name]: url }));

  const ENTRIES = useMemo(() => Object.entries(urls), [urls]);
  const TOTAL   = ENTRIES.length;
  const FILLED  = ENTRIES.filter(([, v]) => v && v.trim()).length;
  const pct     = Math.round((FILLED / TOTAL) * 100);

  const catBrands = useMemo(() => {
    const list = CATEGORIES[cat];
    return list
      ? ENTRIES.filter(([n]) => list.includes(n))
      : ENTRIES;
  }, [cat, ENTRIES]);

  const visible = useMemo(() => catBrands.filter(([name, url]) => {
    const matchSearch = !search || name.toLowerCase().includes(search.toLowerCase());
    const hasSrc      = url && url.trim();
    const matchFilter = filter === "all" || (filter === "filled" && hasSrc) || (filter === "missing" && !hasSrc);
    return matchSearch && matchFilter;
  }), [catBrands, filter, search]);

  const catFilled = catBrands.filter(([, v]) => v && v.trim()).length;
  const catTotal  = catBrands.length;

  // Track changes vs original
  const hasChanges = useMemo(() => {
    const orig = LIQUOR_IMAGES;
    if (Object.keys(urls).length !== Object.keys(orig).length) return true;
    return Object.entries(urls).some(([k, v]) => orig[k] !== v);
  }, [urls]);

  return (
    <div style={{ fontFamily: "'DM Sans', sans-serif", color: T.cream }}>
      {showExport && <ExportModal urls={urls} onClose={() => setShowExport(false)} />}

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 6, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ fontFamily: "'Inter', sans-serif", fontSize: 22, fontWeight: 800, color: T.gold, margin: "0 0 4px" }}>Image Manager</h1>
          <p style={{ color: T.dim, fontSize: 13, margin: 0 }}>Edit, add, or remove bottle image URLs. Export when done to persist to <code style={{ fontSize: 11, color: T.gold }}>images.js</code>.</p>
        </div>
        <button onClick={() => setShowExport(true)}
          style={{ padding: "9px 18px", background: hasChanges ? `${T.gold}25` : "rgba(255,255,255,0.04)", border: `1px solid ${hasChanges ? T.gold + "70" : T.border}`, borderRadius: 9, color: hasChanges ? T.gold : T.muted, fontFamily: "'DM Mono', monospace", fontSize: 12, cursor: "pointer", flexShrink: 0, letterSpacing: "0.05em", transition: "all 0.2s", display: "flex", alignItems: "center", gap: 6 }}>
          {hasChanges && <span style={{ width: 7, height: 7, borderRadius: "50%", background: T.gold, display: "inline-block" }} />}
          Export to images.js
        </button>
      </div>

      {/* Progress bar */}
      <div style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 12, padding: "14px 18px", marginBottom: 20, marginTop: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.cream }}>Coverage</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.gold, fontFamily: "'DM Mono', monospace" }}>{FILLED} / {TOTAL} ({pct}%)</span>
        </div>
        <div style={{ height: 6, background: "rgba(255,255,255,0.08)", borderRadius: 3, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, ${T.gold}, #D4712B)`, borderRadius: 3, transition: "width 0.4s" }} />
        </div>
      </div>

      {/* Category tabs */}
      <div style={{ display: "flex", gap: 4, overflowX: "auto", marginBottom: 14, paddingBottom: 2 }}>
        {Object.keys(CATEGORIES).map(c => {
          const active = cat === c;
          return (
            <button key={c} onClick={() => setCat(c)} style={{ padding: "7px 14px", background: active ? T.gold + "10" : "none", border: `1px solid ${active ? T.gold + "60" : T.border}`, borderRadius: 20, cursor: "pointer", whiteSpace: "nowrap", flexShrink: 0, fontSize: 12, fontWeight: active ? 700 : 500, color: active ? T.gold : T.muted, transition: "all 0.2s" }}>{c}</button>
          );
        })}
      </div>

      {/* Filter + search */}
      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 14, flexWrap: "wrap" }}>
        <div style={{ position: "relative", flex: 1, minWidth: 180 }}>
          <span style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", fontSize: 13, opacity: 0.4 }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search brands..." style={{ width: "100%", padding: "8px 12px 8px 32px", background: "rgba(255,255,255,0.04)", border: `1px solid ${T.border}`, borderRadius: 8, color: T.cream, fontSize: 13, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }} />
        </div>
        {["all", "filled", "missing"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ padding: "7px 14px", background: filter === f ? "rgba(255,255,255,0.07)" : "none", border: `1px solid ${T.border}`, borderRadius: 8, cursor: "pointer", fontSize: 12, color: filter === f ? T.cream : T.muted, fontFamily: "inherit" }}>
            {f === "all" ? `All (${catTotal})` : f === "filled" ? `✓ Filled (${catFilled})` : `✗ Missing (${catTotal - catFilled})`}
          </button>
        ))}
      </div>

      {/* Brand list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {visible.length === 0
          ? <div style={{ textAlign: "center", padding: "40px 0", color: T.dim, fontSize: 13 }}>No brands match.</div>
          : visible.map(([name, url]) => <BrandRow key={name} name={name} url={url} onSave={handleSave} onRemove={handleRemove} />)
        }
        {/* Add brand button always visible when on All or when search empty */}
        {!search && <AddBrandRow onAdd={handleAdd} />}
      </div>
    </div>
  );
}